#pragma once
#define FIRMWARE_VERSION "0.0.1--2026-07-27"
