#pragma once
#define FIRMWARE_VERSION "0.0.1-42fdb5a-2026-09-16"
